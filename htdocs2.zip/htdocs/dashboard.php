<?php
require_once 'conexao.php';

// Verifica se o usuário está logado
verificarLogin();

// Processar filtros
$periodo = isset($_GET['periodo']) ? intval($_GET['periodo']) : 30;
$unidade = isset($_GET['unidade']) ? intval($_GET['unidade']) : 0;
$curso = isset($_GET['curso']) ? intval($_GET['curso']) : 0;
$turno = isset($_GET['turno']) ? intval($_GET['turno']) : 0;

// Função para formatar números
function formatarNumero($numero) {
    return number_format($numero, 1, ',', '.');
}

// Função para buscar os dados de reciclagem
function getDadosReciclagem($periodo, $unidade, $curso, $turno) {
    global $conexao;
    
    $where = "WHERE e.data_entrega >= DATE_SUB(CURDATE(), INTERVAL $periodo DAY) AND e.confirmado = 1";
    
    if ($unidade > 0) {
        $where .= " AND tu.unidade_id = $unidade";
    }
    
    if ($curso > 0) {
        $where .= " AND tu.curso_id = $curso";
    }
    
    if ($turno > 0) {
        $where .= " AND tu.turno_id = $turno";
    }
    
    // Total por tipo de resíduo
    $sql = "SELECT 
                tr.nome, 
                SUM(e.quantidade) as total,
                (SELECT SUM(quantidade) 
                 FROM entregas e2 
                 JOIN turmas tu2 ON e2.turma_id = tu2.id 
                 WHERE e2.tipo_residuo_id = tr.id 
                 AND e2.confirmado = 1
                 AND e2.data_entrega >= DATE_SUB(DATE_SUB(CURDATE(), INTERVAL $periodo DAY), INTERVAL $periodo DAY)
                 " . ($unidade > 0 ? "AND tu2.unidade_id = $unidade" : "") . "
                 " . ($curso > 0 ? "AND tu2.curso_id = $curso" : "") . "
                 " . ($turno > 0 ? "AND tu2.turno_id = $turno" : "") . "
                ) as periodo_anterior
            FROM 
                entregas e
                JOIN turmas tu ON e.turma_id = tu.id
                JOIN tipos_residuos tr ON e.tipo_residuo_id = tr.id
            $where
            GROUP BY 
                tr.id";
    
    $resultado = $conexao->query($sql);
    
    $dados = [];
    $total = 0;
    $total_anterior = 0;
    
    while ($row = $resultado->fetch_assoc()) {
        $dados[$row['nome']] = [
            'total' => $row['total'],
            'periodo_anterior' => $row['periodo_anterior'] ?: 0
        ];
        
        $total += $row['total'];
        $total_anterior += $row['periodo_anterior'] ?: 0;
    }
    
    // Calcular percentuais de mudança
    foreach ($dados as $tipo => $valores) {
        if ($valores['periodo_anterior'] > 0) {
            $dados[$tipo]['variacao'] = (($valores['total'] - $valores['periodo_anterior']) / $valores['periodo_anterior']) * 100;
        } else {
            $dados[$tipo]['variacao'] = 100; // Se não havia dados no período anterior
        }
    }
    
    // Calcular variação total
    $variacao_total = 0;
    if ($total_anterior > 0) {
        $variacao_total = (($total - $total_anterior) / $total_anterior) * 100;
    } else {
        $variacao_total = 100;
    }
    
    return [
        'dados' => $dados,
        'total' => $total,
        'variacao_total' => $variacao_total
    ];
}

// Função para buscar ranking de turmas
function getRankingTurmas($periodo, $unidade, $curso, $turno, $limite = 5) {
    global $conexao;
    
    $where = "WHERE e.data_entrega >= DATE_SUB(CURDATE(), INTERVAL $periodo DAY) AND e.confirmado = 1";
    
    if ($unidade > 0) {
        $where .= " AND tu.unidade_id = $unidade";
    }
    
    if ($curso > 0) {
        $where .= " AND tu.curso_id = $curso";
    }
    
    if ($turno > 0) {
        $where .= " AND tu.turno_id = $turno";
    }
    
    $sql = "SELECT 
                tu.codigo as turma, 
                c.nome as curso,
                SUM(e.quantidade) as total
            FROM 
                entregas e
                JOIN turmas tu ON e.turma_id = tu.id
                JOIN cursos c ON tu.curso_id = c.id
            $where
            GROUP BY 
                tu.id
            ORDER BY 
                total DESC
            LIMIT $limite";
    
    return $conexao->query($sql);
}

// Função para buscar ranking de cursos
function getRankingCursos($periodo, $unidade, $turno, $limite = 5) {
    global $conexao;
    
    $where = "WHERE e.data_entrega >= DATE_SUB(CURDATE(), INTERVAL $periodo DAY) AND e.confirmado = 1";
    
    if ($unidade > 0) {
        $where .= " AND tu.unidade_id = $unidade";
    }
    
    if ($turno > 0) {
        $where .= " AND tu.turno_id = $turno";
    }
    
    $sql = "SELECT 
                c.nome as curso,
                SUM(e.quantidade) as total
            FROM 
                entregas e
                JOIN turmas tu ON e.turma_id = tu.id
                JOIN cursos c ON tu.curso_id = c.id
            $where
            GROUP BY 
                c.id
            ORDER BY 
                total DESC
            LIMIT $limite";
    
    return $conexao->query($sql);
}

// Buscar dados para a página
$dadosReciclagem = getDadosReciclagem($periodo, $unidade, $curso, $turno);
$rankingTurmas = getRankingTurmas($periodo, $unidade, $curso, $turno);
$rankingCursos = getRankingCursos($periodo, $unidade, $turno);

// Preparar dados para o gráfico
$labels = [];
$data = [];

// Dados simulados para o gráfico
$meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho'];
foreach ($meses as $mes) {
    $labels[] = $mes;
    $data[] = rand(10, 50); // Valores aleatórios para exemplo
}

// Buscar unidades para o filtro
$unidades_filtro = obterDados("unidades", "", "id, nome", "nome");
$unidades_array = [];
while ($row = $unidades_filtro->fetch_assoc()) {
    $unidades_array[] = $row;
}

// Buscar cursos para o filtro
$cursos_filtro = obterDados("cursos", "", "id, nome", "nome");
$cursos_array = [];
while ($row = $cursos_filtro->fetch_assoc()) {
    $cursos_array[] = $row;
}

// Buscar turnos para o filtro
$turnos_filtro = obterDados("turnos", "", "id, nome", "nome");
$turnos_array = [];
while ($row = $turnos_filtro->fetch_assoc()) {
    $turnos_array[] = $row;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <title>Dashboard - Ser Recicla</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            background-color: #f5f5f5;
        }
        
        header {
            background-color: #2b2640;
            color: white;
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }
        
        .header-container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            height: 40px;
        }
        
        .nav-links {
            display: flex;
            gap: 30px;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }
        
        .nav-links a:hover {
            color: #00ff88;
        }
        
        .logout-btn {
            background-color: #a82828;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        
        .logout-btn:hover {
            background-color: #8a2020;
        }
        
        .main-content {
            flex: 1;
            width: 90%;
            max-width: 1200px;
            margin: 30px auto;
        }
        
        .dashboard-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .dashboard-header h1 {
            color: #2b2640;
            margin-bottom: 10px;
        }
        
        .dashboard-header p {
            color: #666;
        }
        
        .filters {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        
        .filter-group {
            flex: 1;
            min-width: 200px;
        }
        
        .filter-group label {
            display: block;
            margin-bottom: 5px;
            color: #2b2640;
            font-weight: bold;
        }
        
        .filter-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: white;
            color: #333;
        }
        
        .filter-btn {
            background-color: #2b2640;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            margin-top: 20px;
            transition: background-color 0.3s;
        }
        
        .filter-btn:hover.filter-btn:hover {
            background-color: #3a3456;
        }
        
        .cards-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card {
            background-color: #2b2640;
            color: white;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .card h3 {
            color: #00ff88;
            margin-bottom: 15px;
        }
        
        .card .value {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .card .change {
            color: #00ff88;
        }
        
        .negative {
            color: #ff6b6b;
        }
        
        .charts-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .chart-card {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .chart-card h3 {
            text-align: center;
            margin-bottom: 15px;
            color: #2b2640;
        }
        
        .chart-area {
            height: 300px;
            position: relative;
        }
        
        .ranking-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .ranking-card {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .ranking-card h3 {
            text-align: center;
            margin-bottom: 15px;
            color: #2b2640;
        }
        
        .ranking-list {
            list-style: none;
        }
        
        .ranking-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        
        .ranking-position {
            font-weight: bold;
            color: #2b2640;
            width: 30px;
        }
        
        .ranking-name {
            flex: 1;
            padding: 0 10px;
        }
        
        .ranking-value {
            background-color: #2b2640;
            color: #00ff88;
            padding: 2px 12px;
            border-radius: 20px;
            font-weight: bold;
        }
        
        .no-data {
            text-align: center;
            color: #666;
            padding: 20px 0;
        }
        
        footer {
            background-color: #a82828;
            color: white;
            padding: 20px 0;
            margin-top: auto;
        }
        
        .footer-container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }
        
        .footer-col {
            flex: 1;
            min-width: 250px;
            margin-bottom: 20px;
        }
        
        .footer-col h3 {
            margin-bottom: 15px;
        }
        
        .social-icons {
            display: flex;
            gap: 15px;
            margin-top: 15px;
        }
        
        .social-icons a {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: white;
            color: #a82828;
            transition: transform 0.3s;
        }
        
        .social-icons a:hover {
            transform: scale(1.1);
        }
        
        .contact-input {
            display: flex;
            margin-top: 15px;
        }
        
        .contact-input input {
            flex: 1;
            padding: 10px;
            border: none;
            border-radius: 5px 0 0 5px;
        }
        
        .contact-input button {
            background-color: #2b2640;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 0 5px 5px 0;
            cursor: pointer;
        }
        
        .copyright {
            text-align: center;
            padding: 15px 0;
            background-color: #000;
            color: white;
        }
        
        @media (max-width: 768px) {
            .charts-container, .ranking-container {
                grid-template-columns: 1fr;
            }
            
            .nav-links {
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <img src="home_img/Bandeira_do_Pará.svg.png" alt="Bandeira do Pará" class="logo">
            <div class="nav-links">
                <a href="home.php">HOME</a>
                <a href="dashboard.php">DASHBOARD</a>
                <a href="entrega.php">ENTREGAR RESÍDUOS</a>
            </div>
            <a href="logout.php"><button class="logout-btn">Logout</button></a>
        </div>
    </header>
    
    <div class="main-content">
        <div class="dashboard-header">
            <h1>Dashboard Ser Recicla</h1>
            <p>Monitoramento e análise de dados de reciclagem</p>
        </div>
        
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="GET" class="filters">
            <div class="filter-group">
                <label for="filterPeriodo">Período</label>
                <select id="filterPeriodo" name="periodo">
                    <option value="7" <?php echo $periodo == 7 ? 'selected' : ''; ?>>Últimos 7 dias</option>
                    <option value="30" <?php echo $periodo == 30 ? 'selected' : ''; ?>>Últimos 30 dias</option>
                    <option value="90" <?php echo $periodo == 90 ? 'selected' : ''; ?>>Últimos 90 dias</option>
                    <option value="180" <?php echo $periodo == 180 ? 'selected' : ''; ?>>Últimos 6 meses</option>
                    <option value="365" <?php echo $periodo == 365 ? 'selected' : ''; ?>>Último ano</option>
                </select>
            </div>
            
            <div class="filter-group">
                <label for="filterUnidade">Unidade</label>
                <select id="filterUnidade" name="unidade">
                    <option value="0">Todas as unidades</option>
                    <?php foreach ($unidades_array as $unidade_filtro): ?>
                        <option value="<?php echo $unidade_filtro['id']; ?>" <?php echo $unidade == $unidade_filtro['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($unidade_filtro['nome']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="filter-group">
                <label for="filterCurso">Curso</label>
                <select id="filterCurso" name="curso">
                    <option value="0">Todos os cursos</option>
                    <?php foreach ($cursos_array as $curso_filtro): ?>
                        <option value="<?php echo $curso_filtro['id']; ?>" <?php echo $curso == $curso_filtro['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($curso_filtro['nome']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="filter-group">
                <label for="filterTurno">Turno</label>
                <select id="filterTurno" name="turno">
                    <option value="0">Todos os turnos</option>
                    <?php foreach ($turnos_array as $turno_filtro): ?>
                        <option value="<?php echo $turno_filtro['id']; ?>" <?php echo $turno == $turno_filtro['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($turno_filtro['nome']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="filter-group">
                <button type="submit" class="filter-btn">Aplicar Filtros</button>
            </div>
        </form>
        
        <div class="cards-container">
            <div class="card">
                <h3>Total Reciclado</h3>
                <div class="value"><?php echo formatarNumero($dadosReciclagem['total']); ?> kg</div>
                <div class="change <?php echo $dadosReciclagem['variacao_total'] < 0 ? 'negative' : ''; ?>">
                    <?php echo ($dadosReciclagem['variacao_total'] >= 0 ? '+' : '') . formatarNumero($dadosReciclagem['variacao_total']); ?>% vs período anterior
                </div>
            </div>
            
            <?php foreach ($dadosReciclagem['dados'] as $tipo => $valores): ?>
                <div class="card">
                    <h3><?php echo htmlspecialchars($tipo); ?></h3>
                    <div class="value"><?php echo formatarNumero($valores['total']); ?> kg</div>
                    <div class="change <?php echo $valores['variacao'] < 0 ? 'negative' : ''; ?>">
                        <?php echo ($valores['variacao'] >= 0 ? '+' : '') . formatarNumero($valores['variacao']); ?>% vs período anterior
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="charts-container">
            <div class="chart-card">
                <h3>Evolução por tipo de resíduo</h3>
                <div class="chart-area">
                    <canvas id="chartEvolucao"></canvas>
                </div>
            </div>
            
            <div class="chart-card">
                <h3>Comparativo por Unidade</h3>
                <div class="chart-area">
                    <canvas id="chartUnidades"></canvas>
                </div>
            </div>
        </div>
        
        <div class="ranking-container">
            <div class="ranking-card">
                <h3>Top 5 Turmas</h3>
                <ul class="ranking-list">
                    <?php if ($rankingTurmas && $rankingTurmas->num_rows > 0): ?>
                        <?php $i = 1; while ($turma = $rankingTurmas->fetch_assoc()): ?>
                            <li class="ranking-item">
                                <span class="ranking-position"><?php echo $i; ?>.</span>
                                <span class="ranking-name"><?php echo htmlspecialchars($turma['turma']); ?> - <?php echo htmlspecialchars($turma['curso']); ?></span>
                                <span class="ranking-value"><?php echo formatarNumero($turma['total']); ?> kg</span>
                            </li>
                        <?php $i++; endwhile; ?>
                    <?php else: ?>
                        <li class="ranking-item no-data">Nenhum dado disponível</li>
                    <?php endif; ?>
                </ul>
            </div>
            
            <div class="ranking-card">
                <h3>Top 5 Cursos</h3>
                <ul class="ranking-list">
                    <?php if ($rankingCursos && $rankingCursos->num_rows > 0): ?>
                        <?php $i = 1; while ($curso = $rankingCursos->fetch_assoc()): ?>
                            <li class="ranking-item">
                                <span class="ranking-position"><?php echo $i; ?>.</span>
                                <span class="ranking-name"><?php echo htmlspecialchars($curso['curso']); ?></span>
                                <span class="ranking-value"><?php echo formatarNumero($curso['total']); ?> kg</span>
                            </li>
                        <?php $i++; endwhile; ?>
                    <?php else: ?>
                        <li class="ranking-item no-data">Nenhum dado disponível</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    
    <footer>
        <div class="footer-container">
            <div class="footer-col">
                <h3>O Melhor para nossa cidade!</h3>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
            
            <div class="footer-col">
                <h3>UNAMA</h3>
                <p>Projeto Ser Recicla</p>
            </div>
            
            <div class="footer-col">
                <h3>Contato</h3>
                <p>Entre em contato com a equipe do projeto</p>
                <div class="contact-input">
                    <input type="text" placeholder="Seu email">
                    <button><i class="fas fa-envelope"></i></button>
                </div>
            </div>
        </div>
        
        <div class="copyright">
            &#169; 2025 Universidade da Amazônia - COP30
        </div>
    </footer>
    
    <script>
        // Configurações de cores para os gráficos
        const coresTopoResiduo = [
            'rgba(255, 99, 132, 0.2)',
            'rgba(54, 162, 235, 0.2)',
            'rgba(255, 206, 86, 0.2)',
            'rgba(75, 192, 192, 0.2)'
        ];
        
        const bordaCoresTopoResiduo = [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)'
        ];
        
        const coresUnidades = [
            'rgba(153, 102, 255, 0.6)',
            'rgba(255, 159, 64, 0.6)'
        ];
        
        // Dados para os gráficos (simulados para exemplo)
        const dadosEvolucao = {
            labels: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho'],
            datasets: [
                {
                    label: 'Alumínio',
                    data: [12, 15, 18, 14, 22, 25],
                    backgroundColor: coresTopoResiduo[0],
                    borderColor: bordaCoresTopoResiduo[0],
                    borderWidth: 2,
                    tension: 0.4
                },
                {
                    label: 'Vidro',
                    data: [18, 20, 25, 22, 30, 35],
                    backgroundColor: coresTopoResiduo[1],
                    borderColor: bordaCoresTopoResiduo[1],
                    borderWidth: 2,
                    tension: 0.4
                },
                {
                    label: 'Pano',
                    data: [8, 10, 12, 15, 18, 20],
                    backgroundColor: coresTopoResiduo[2],
                    borderColor: bordaCoresTopoResiduo[2],
                    borderWidth: 2,
                    tension: 0.4
                },
                {
                    label: 'PET',
                    data: [10, 12, 15, 18, 20, 22],
                    backgroundColor: coresTopoResiduo[3],
                    borderColor: bordaCoresTopoResiduo[3],
                    borderWidth: 2,
                    tension: 0.4
                }
            ]
        };
        
        const dadosUnidades = {
            labels: ['Alumínio', 'Vidro', 'Pano', 'PET'],
            datasets: [
                {
                    label: 'Alcindo Cacela',
                    data: [35, 45, 28, 32],
                    backgroundColor: coresUnidades[0]
                },
                {
                    label: 'Ananindeua',
                    data: [25, 35, 20, 15],
                    backgroundColor: coresUnidades[1]
                }
            ]
        };
        
        // Inicializar os gráficos quando a página carregar
        document.addEventListener('DOMContentLoaded', function() {
            // Gráfico de evolução
            const ctxEvolucao = document.getElementById('chartEvolucao').getContext('2d');
            const chartEvolucao = new Chart(ctxEvolucao, {
                type: 'line',
                data: dadosEvolucao,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Quantidade (kg)'
                            }
                        }
                    }
                }
            });
            
            // Gráfico de comparativo por unidade
            const ctxUnidades = document.getElementById('chartUnidades').getContext('2d');
            const chartUnidades = new Chart(ctxUnidades, {
                type: 'bar',
                data: dadosUnidades,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Quantidade (kg)'
                            }
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>