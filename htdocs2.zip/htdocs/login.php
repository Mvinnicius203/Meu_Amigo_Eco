<?php
// Inclui o arquivo de conexão
require_once 'conexao.php';

// Inicia a sessão se ainda não estiver iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$mensagem = "";

// Verifica se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = limpar_texto($_POST['usuario']);
    $senha = $_POST['senha'];
    
    // Verifica se os campos estão preenchidos
    if (!empty($usuario) && !empty($senha)) {
        // Busca o usuário no banco de dados
        $sql = "SELECT id, nome, email, senha, perfil FROM usuarios WHERE email = ?";
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("s", $usuario);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($resultado && $resultado->num_rows === 1) {
            $usuario_db = $resultado->fetch_assoc();
            
            // Verifica a senha (temporariamente sem usar password_verify para depuração)
            // Para o administrador padrão com senha hash '$2y$10$8MvTUv68YRO/Qj3eIrP.u.ErO.QGZtBkN0kzEPXxhG4M9Jf8Q.NpS'
            if ($usuario_db['email'] == 'admin@ecotrackaparaense.com.br' && $senha == 'admin123') {
                // Login direto para o admin padrão
                $_SESSION['usuario_id'] = $usuario_db['id'];
                $_SESSION['usuario_nome'] = $usuario_db['nome'];
                $_SESSION['usuario_perfil'] = $usuario_db['perfil'];
                
                // Redireciona para a página principal
                header("Location: home.php");
                exit;
            }
            // Para outros usuários, verifica com password_verify
            else if (password_verify($senha, $usuario_db['senha'])) {
                // Login bem-sucedido
                $_SESSION['usuario_id'] = $usuario_db['id'];
                $_SESSION['usuario_nome'] = $usuario_db['nome'];
                $_SESSION['usuario_perfil'] = $usuario_db['perfil'];
                
                // Redireciona para a página principal
                header("Location: home.php");
                exit;
            } else {
                $mensagem = "Senha incorreta!";
            }
        } else {
            $mensagem = "Usuário não encontrado!";
        }
        
        if ($stmt) {
            $stmt->close();
        }
    } else {
        $mensagem = "Por favor, preencha todos os campos!";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ECO TRACK Paraense</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        
        body {
            width: 100%;
            height: 100vh;
            display: flex;
            flex-direction: column;
            background-color: #f8f9fa;
        }
        
        header {
            background-color: #2b2640;
            color: white;
            padding: 15px 0;
        }
        
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .inicio img {
            height: 40px;
        }
        
        nav ul {
            display: flex;
            list-style: none;
        }
        
        nav ul li {
            margin: 0 15px;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }
        
        nav ul li a:hover {
            color: #00ff88;
        }
        
        .main-login {
            display: flex;
            flex: 1;
        }
        
        .left-login, .right-login {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 30px;
        }
        
        .left-login h1 {
            color: #2b2640;
            font-size: 2.5rem;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .login-png {
            max-width: 100%;
            height: auto;
            max-height: 400px;
        }
        
        .card-login {
            background-color: #2b2640;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        
        .card-login h1 {
            color: #00ff88;
            text-align: center;
            margin-bottom: 20px;
            font-size: 2rem;
        }
        
        .mensagem-alerta {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: center;
        }
        
        .textfield {
            margin-bottom: 20px;
        }
        
        .textfield label {
            display: block;
            color: white;
            margin-bottom: 10px;
            font-size: 0.9rem;
        }
        
        .textfield input {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 5px;
            background-color: #3a3456;
            color: white;
            font-size: 1rem;
        }
        
        .textfield input::placeholder {
            color: #a0a0a0;
        }
        
        .botoes {
            display: flex;
            justify-content: space-between;
        }
        
        .btn-login {
            width: 48%;
            padding: 12px;
            border: none;
            border-radius: 5px;
            background-color: #00ff88;
            color: #2b2640;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .btn-login:hover {
            background-color: #00cc6a;
        }
        
        .bot {
            width: 48%;
            text-decoration: none;
        }
        
        @media (max-width: 950px) {
            .main-login {
                flex-direction: column;
            }
            
            .left-login, .right-login {
                width: 100%;
            }
            
            .left-login h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <header id="header">
        <div class="container">
            <div class="flex">
                <a href="index.php" class="inicio"><img class="i" src="home_img/Bandeira_do_Pará.svg.png" alt="Bandeira do Pará"></a>
                <nav>
                    <ul>
                        <li><a href="index.php">HOME</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <div class="main-login">
        <div class="left-login">
            <h1>Faça login <br> ou cadastre-se</h1>
            <img src="home_img/login-animate.svg" class="login-png" alt="Ilustração de login">
        </div>
        <div class="right-login">
            <div class="card-login">
                <h1>Login</h1>
                
                <?php if (!empty($mensagem)): ?>
                    <div class="mensagem-alerta"><?php echo $mensagem; ?></div>
                <?php endif; ?>
                
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="textfield">
                        <label for="usuario">Usuário (E-mail)</label>
                        <input type="text" name="usuario" id="usuario" placeholder="Seu e-mail">
                    </div>
                    <div class="textfield">
                        <label for="senha">Senha</label>
                        <input type="password" name="senha" id="senha" placeholder="Sua senha">
                    </div>
                    <div class="botoes">
                        <button type="submit" class="btn-login">Login</button>
                        <a class="bot" href="cadastro.php"><button type="button" class="btn-login">Cadastro</button></a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Debug para ver informações de login (remover em produção) -->
    <?php if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST'): ?>
    <div style="margin: 20px; padding: 20px; background: #f0f0f0; border-radius: 5px;">
        <h3>Debug Info:</h3>
        <p>Usuário: <?php echo htmlspecialchars($usuario ?? 'Não informado'); ?></p>
        <p>Senha informada: <?php echo !empty($senha) ? '******' : 'Não informada'; ?></p>
        <p>Resultado da consulta: <?php echo isset($resultado) ? ($resultado->num_rows > 0 ? 'Usuário encontrado' : 'Usuário não encontrado') : 'Consulta não executada'; ?></p>
        <?php if (isset($usuario_db)): ?>
        <p>Email no banco: <?php echo htmlspecialchars($usuario_db['email']); ?></p>
        <p>Perfil: <?php echo htmlspecialchars($usuario_db['perfil']); ?></p>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</body>
</html>