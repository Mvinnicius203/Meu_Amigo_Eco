<?php
require_once 'conexao.php';

// Verifica se o usuário está logado
verificarLogin();

$mensagem = "";
$tipo_mensagem = "";

// Busca os dados para os selects
$tipos_residuos = obterDados("tipos_residuos", "", "id, nome", "nome");
$cursos = obterDados("cursos", "", "id, nome", "nome");
$turnos = obterDados("turnos", "", "id, nome", "nome");
$unidades = obterDados("unidades", "", "id, nome", "nome");

// Verifica se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $quantidade = floatval($_POST['quantidade']);
    $tipo_residuo_id = intval($_POST['tipoResiduo']);
    $turma_codigo = limpar_texto($_POST['turma']);
    $curso_id = intval($_POST['curso']);
    $semestre = intval($_POST['semestre']);
    $turno_id = intval($_POST['turno']);
    $unidade_id = intval($_POST['unidade']);
    
    // Verifica se a turma já existe ou precisa ser criada
    $sql_turma = "SELECT id FROM turmas WHERE codigo = ? AND curso_id = ? AND semestre = ? AND turno_id = ? AND unidade_id = ?";
    $stmt_turma = $conexao->prepare($sql_turma);
    $stmt_turma->bind_param("siiii", $turma_codigo, $curso_id, $semestre, $turno_id, $unidade_id);
    $stmt_turma->execute();
    $resultado_turma = $stmt_turma->get_result();
    
    if ($resultado_turma->num_rows > 0) {
        // Turma já existe
        $turma_id = $resultado_turma->fetch_assoc()['id'];
    } else {
        // Criar nova turma
        $sql_nova_turma = "INSERT INTO turmas (codigo, curso_id, semestre, turno_id, unidade_id) VALUES (?, ?, ?, ?, ?)";
        $stmt_nova_turma = $conexao->prepare($sql_nova_turma);
        $stmt_nova_turma->bind_param("siiii", $turma_codigo, $curso_id, $semestre, $turno_id, $unidade_id);
        
        if ($stmt_nova_turma->execute()) {
            $turma_id = $stmt_nova_turma->insert_id;
        } else {
            $mensagem = "Erro ao criar a turma: " . $stmt_nova_turma->error;
            $tipo_mensagem = "erro";
        }
        
        $stmt_nova_turma->close();
    }
    
    $stmt_turma->close();
    
    // Se temos uma turma válida, registramos a entrega
    if (isset($turma_id) && $turma_id > 0) {
        // Registra a entrega usando a procedure
        $sql = "CALL sp_registrar_entrega(?, ?, ?, ?, ?)";
        $stmt = $conexao->prepare($sql);
        $usuario_id = $_SESSION['usuario_id'];
        $stmt->bind_param("iiidi", $usuario_id, $turma_id, $tipo_residuo_id, $quantidade, $usuario_id);
        
        if ($stmt->execute()) {
            $mensagem = "Entrega registrada com sucesso!";
            $tipo_mensagem = "sucesso";
        } else {
            $mensagem = "Erro ao registrar entrega: " . $stmt->error;
            $tipo_mensagem = "erro";
        }
        
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Entrega de Resíduos - Ser Recicla</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            background-color: #f5f5f5;
        }
        
        header {
            background-color: #2b2640;
            color: white;
            padding: 15px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }
        
        .header-container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            height: 40px;
        }
        
        .nav-links {
            display: flex;
            gap: 30px;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }
        
        .nav-links a:hover {
            color: #00ff88;
        }
        
        .logout-btn {
            background-color: #a82828;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        
        .logout-btn:hover {
            background-color: #8a2020;
        }
        
        .main-content {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px 0;
        }
        
        .form-container {
            background-color: #2b2640;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            width: 90%;
            max-width: 700px;
            padding: 30px;
            color: white;
        }
        
        .form-title {
            text-align: center;
            margin-bottom: 30px;
            color: #00ff88;
            font-size: 24px;
        }
        
        .mensagem {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }
        
        .mensagem.sucesso {
            background-color: #d4edda;
            color: #155724;
        }
        
        .mensagem.erro {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        
        input, select {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 5px;
            background-color: #3a3456;
            color: white;
        }
        
        input::placeholder, select::placeholder {
            color: #ccc;
        }
        
        .form-row {
            display: flex;
            gap: 20px;
        }
        
        .form-row .form-group {
            flex: 1;
        }
        
        .btn-submit {
            background-color: #00ff88;
            color: #2b2640;
            border: none;
            width: 100%;
            padding: 12px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            font-size: 16px;
            margin-top: 20px;
            transition: background-color 0.3s;
        }
        
        .btn-submit:hover {
            background-color: #00cc6a;
        }
        
        footer {
            background-color: #a82828;
            color: white;
            padding: 20px 0;
            margin-top: auto;
        }
        
        .footer-container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }
        
        .footer-col {
            flex: 1;
            min-width: 250px;
            margin-bottom: 20px;
        }
        
        .footer-col h3 {
            margin-bottom: 15px;
        }
        
        .social-icons {
            display: flex;
            gap: 15px;
            margin-top: 15px;
        }
        
        .social-icons a {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: white;
            color: #a82828;
            transition: transform 0.3s;
        }
        
        .social-icons a:hover {
            transform: scale(1.1);
        }
        
        .contact-input {
            display: flex;
            margin-top: 15px;
        }
        
        .contact-input input {
            border-radius: 5px 0 0 5px;
        }
        
        .contact-input button {
            background-color: #2b2640;
            color: white;
            border: none;
            padding: 12px 15px;
            border-radius: 0 5px 5px 0;
            cursor: pointer;
        }
        
        .copyright {
            text-align: center;
            padding: 15px 0;
            background-color: #000;
            color: white;
        }
        
        @media (max-width: 768px) {
            .form-row {
                flex-direction: column;
                gap: 0;
            }
            
            .nav-links {
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <img src="home_img/Bandeira_do_Pará.svg.png" alt="Bandeira do Pará" class="logo">
            <div class="nav-links">
                <a href="home.php">HOME</a>
                <a href="dashboard.php">DASHBOARD</a>
                <a href="entrega.php">ENTREGAR RESÍDUOS</a>
            </div>
            <a href="logout.php"><button class="logout-btn">Logout</button></a>
        </div>
    </header>
    
    <div class="main-content">
        <div class="form-container">
            <h2 class="form-title">REGISTRAR ENTREGA</h2>
            
            <?php if (!empty($mensagem)): ?>
                <div class="mensagem <?php echo $tipo_mensagem; ?>">
                    <?php echo $mensagem; ?>
                </div>
            <?php endif; ?>
            
            <form id="entregaForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="quantidade">Quantidade (kg)</label>
                    <input type="number" id="quantidade" name="quantidade" step="0.01" min="0.01" placeholder="Ex: 2.5" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="tipoResiduo">Tipo de Resíduo</label>
                        <select id="tipoResiduo" name="tipoResiduo" required>
                            <option value="">Selecione</option>
                            <?php while ($tipo = $tipos_residuos->fetch_assoc()): ?>
                                <option value="<?php echo $tipo['id']; ?>"><?php echo htmlspecialchars($tipo['nome']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="turma">Turma</label>
                        <input type="text" id="turma" name="turma" placeholder="Ex: CC3VA" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="curso">Curso</label>
                        <select id="curso" name="curso" required>
                            <option value="">Selecione</option>
                            <?php while ($curso = $cursos->fetch_assoc()): ?>
                                <option value="<?php echo $curso['id']; ?>"><?php echo htmlspecialchars($curso['nome']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="semestre">Semestre</label>
                        <select id="semestre" name="semestre" required>
                            <option value="">Selecione</option>
                            <?php for ($i = 1; $i <= 8; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?>º</option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="turno">Turno</label>
                        <select id="turno" name="turno" required>
                            <option value="">Selecione</option>
                            <?php while ($turno = $turnos->fetch_assoc()): ?>
                                <option value="<?php echo $turno['id']; ?>"><?php echo htmlspecialchars($turno['nome']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="unidade">Unidade</label>
                        <select id="unidade" name="unidade" required>
                            <option value="">Selecione</option>
                            <?php while ($unidade = $unidades->fetch_assoc()): ?>
                                <option value="<?php echo $unidade['id']; ?>"><?php echo htmlspecialchars($unidade['nome']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                
                <button type="submit" class="btn-submit">REGISTRAR ENTREGA</button>
            </form>
        </div>
    </div>
    
    <footer>
        <div class="footer-container">
            <div class="footer-col">
                <h3>O Melhor para nossa cidade!</h3>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
            
            <div class="footer-col">
                <h3>UNAMA</h3>
                <p>Projeto Ser Recicla</p>
            </div>
            
            <div class="footer-col">
                <h3>Contato</h3>
                <p>Entre em contato com a equipe do projeto</p>
                <div class="contact-input">
                    <input type="text" placeholder="Seu email">
                    <button><i class="fas fa-envelope"></i></button>
                </div>
            </div>
        </div>
        
        <div class="copyright">
            &#169; 2025 Universidade da Amazônia - COP30
        </div>
    </footer>
</body>
</html>